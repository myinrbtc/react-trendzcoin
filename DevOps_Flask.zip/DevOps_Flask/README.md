DevOps Readme About Flask

const BlackBear = artifacts.require("BlackBear");

module.exports = function(deployer) {
    deployer.deploy(BlackBear);
};
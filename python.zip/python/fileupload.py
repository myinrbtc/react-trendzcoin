import logging
import boto3
from botocore.exceptions import ClientError
import os


def upload_file(file_name, bucket, object_name=None):
    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
        if object_name.startswith('upload/'):
            new_file_name = f'renamed/rename_{os.path.basename(object_name)}'
            s3_client.copy_object(
                Bucket=bucket,
                CopySource={'Bucket': bucket, 'Key': object_name},
                Key=new_file_name
            )
        else:
            print(f"File {object_name} not in the 'upload' folder. Ignoring.")

        print(f"File uploaded successfully to {bucket}/{object_name}")
        print(response)
    except ClientError as e:
        logging.error(e)
        return False
    return True

file_path = r'F:/DevOps_HeroVired/Automation/awesomeweb1.png'
print(f"File Path: {file_path}")
bucket_name = 'surenderb3'
object_name = 'upload/awesomeweb1.png'

upload_file(file_path, bucket_name, object_name)
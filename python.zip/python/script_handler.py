import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')


def lambda_handler(event, context):
    # print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    print(bucket)
    key = urllib.parse.unquote_plus(
        event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    print(key)
    try:
        if key.startswith('upload/'):
            new_file_name = f'renamed/rename_{os.path.basename(key)}'
            s3.copy_object(
                Bucket=bucket,
                CopySource={'Bucket': bucket, 'Key': key},
                Key=new_file_name
            )
            print(
                f"File {key} renamed to {new_file_name} and moved to 'renamed' folder.")
            # response = s3.get_object(Bucket=bucket, Key=key)
            # print("CONTENT TYPE: " + response['ContentType'])
            # return response['ContentType']
        else:
            print(f"File {key} not in the 'upload' folder. Ignoring.")

        return {
            'statusCode': 200,
            'body': 'Function executed successfully!'
        }

    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e

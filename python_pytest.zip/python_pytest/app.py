from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/hello', methods=['GET'])
def hello():
    return 'hello'

@app.route('/calculate_si', methods=['POST'])
def calculate_si():
    data = request.get_json()
    principle = data.get('principle')
    rate = data.get('rate')
    time = data.get('time')
    if principle is None or rate is None or time is None:
        return jsonify({"error": "missing data"}),400
    # to validate if the input is in int or not
    try:
        principle = float(principle)
        rate = float(rate)
        time = float(time)
    except ValueError:
        return jsonify({'error': 'Wrong Format'}), 400

    si = (principle * rate * time)/100
    return jsonify({'si': si, 'amount': si+principle})

if __name__ == '__main__':
    app.run(debug=True)
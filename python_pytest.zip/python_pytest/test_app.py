import pytest
from app import app as flask_app
from flask import json

@pytest.fixture
def app():
    yield flask_app

@pytest.fixture
def client(app):
    return app.test_client()

def test_hello(client):
    res = client.get('/hello')
    assert res.status_code == 200

def test_calculation_si(client):
    res = client.post('/calculate_si', json={
        "principle": 1000,
        "rate": 5,
        "time": 5
    }) #si = 250
    data = json.loads(res.data)
    assert res.status_code == 200
    assert data['si'] == 250

def test_string_calculation_si(client):
    res = client.post('/calculate_si', json={
        "principle": 'hundred',
        "rate": 'five',
        "time": 'five'
    }) #si = 250
    data = json.loads(res.data)
    assert res.status_code == 400
    assert data['error'] == 'Wrong Format'

def test_limited_param_calculation_si(client):
    res = client.post('/calculate_si', json={
        "principle": 1000,
        "rate": 5
    }) #si = 250
    assert res.status_code == 400
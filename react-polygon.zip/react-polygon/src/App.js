import React from 'react';
import './App.css';
import Web3 from 'web3';
import { ABI, CONTRACT_ADDRESS } from './constant/';

 (async() => {
    if (window.ethereum) {
        try {
            // Request account access
            await window.ethereum.send('eth_requestAccounts');

            //await window.ethereum.send('wallet_requestPermissions');
            //await window.ethereum.send('eth_sendTransaction');

            const web3 = new Web3(window.ethereum);
            var accounts = await web3.eth.getAccounts();
            var account_balance = await web3.eth.getBalance(accounts[0]);
            var account = accounts[0];

            //console.log(account);
            //console.log(account_balance);
            //web3.eth.defaultAccount = '0x5e61592E3FcA39951E1f5CeE12081Dff5f46C74a';
            //var defaultAccount = web3.eth.defaultAccount;

            // creating contract Object for calling contract methods 
            var contract = new web3.eth.Contract(ABI, CONTRACT_ADDRESS);

            //console.log(contract);

            contract.methods.multisendTRX(['0x5e61592E3FcA39951E1f5CeE12081Dff5f46C74a'], [1000000000])
                .send({ from: account, gasPrice: '0x2CB417800' }, function(error, transactionHash) {
                    console.log(transactionHash);
                    console.log(error);
                });
        } catch (error) {
            // User denied account access...
            console.log(error);
            console.error("User denied account access : " + error);
        }
    } else if (window.web3) {
        window.web3 = new Web3(window.web3.currentProvider);
    } else {
        window.alert('Non-Ethereum browser detected. You should consider trying MetaMask!')
    }
})();

const App = () => {
    //console.log(Web3);
    //ConnectMetaMask();
    return ( <div className = "App" >
      <h1 > ggggggg </h1>
        </div >
    );
}

export default App;
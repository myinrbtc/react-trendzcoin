import React from 'react';
//import UseState from './component/Hooks/UseState';
//import UseEffect from './component/Hooks/UseEffect';
//import UseReducer from './component/Hooks/UseReducer';
//import Todo from './component/todo-react/todo';
import Temprature from './component/weather/Temprature';
const App = () => {
  return (
    <>
      <Temprature />
    </>
  );
}
export default App
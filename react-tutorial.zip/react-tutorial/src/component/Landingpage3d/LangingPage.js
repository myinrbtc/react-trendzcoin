import React from "react";
const LandingPage = () => {
    return (
      <mesh>
        <boxGeometry />
        <meshBasicMaterial color="red" />
      </mesh>
  )
}

export default LandingPage;
import React, { useState, useEffect } from 'react'
const Weather = ({ tempInfo }) => {
    const [weatherState, setWeatherState] = useState('');
    const { temp, humidity, pressure, temp_max, temp_min, feels_like, sunrise, sunset, country, weatherMood, name, speed } = tempInfo;
    let sunriseMiliSeconds = sunrise * 1000;
    let sunsetMiliSeconds = sunset * 1000;
    let date1 = new Date(sunriseMiliSeconds);
    let date2 = new Date(sunsetMiliSeconds);
    let timeStrSunrise = `${date1.getHours()} : ${date1.getMinutes()} : ${date1.getSeconds()} `;
    let timeStrSunset = `${date2.getHours()} : ${date2.getMinutes()} : ${date2.getSeconds()} `;

    useEffect(() => {
        if (weatherMood)
        {
            switch (weatherMood) {
                case 'Clouds': setWeatherState('wi-day-cloudy');
                    break;
                case 'Haze': setWeatherState('wi-fog');
                    break;
                case 'Clear': setWeatherState('wi-day-sunny');
                    break;
                case 'Mist': setWeatherState('wi-dust');
                    break;
                default:
                    setWeatherState('wi-day-sunny');
                    break;
            }
          }
    }, [weatherMood])
    
    return (
        <>
            <article className='widget'>
                <div className='weatherIcon'>
                    <i className={`wi ${weatherState}`}></i>
                </div>
                <div className='weatherInfo'>
                    <div className='temperature'>
                        <span>{temp}&deg;</span>
                    </div>
                    <div className='description'>
                        <div className='weatherCondition'>{weatherMood}</div>
                        <div className='place'>{name}, {country}</div>
                    </div>
                </div>
                <div className='date'>{new Date().toLocaleString()}</div>
                <div className='extra-temp'>
                    <div className='temp-info-minmax'>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-sunset'}></i></p>
                            <p className='extra-info-leftside'>{ timeStrSunrise }  <br /> Sunset</p>
                        </div>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-sunrise'}></i></p>
                            <p className='extra-info-leftside'> {timeStrSunset } <br /> Sunrise</p>
                        </div>
                    </div>
                    <div className='weather-extra-info'>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-humidity'}></i></p>
                            <p className='extra-info-leftside'> { humidity } <br /> Humidity</p>
                        </div>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-strong-wind'}></i></p>
                            <p className='extra-info-leftside'> { speed } <br /> Speed</p>
                        </div>
                    </div>
                    <div className='temp-info-minmax'>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-barometer'}></i></p>
                            <p className='extra-info-leftside'>{ pressure }  <br /> Pressure</p>
                        </div>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-sunrise'}></i></p>
                            <p className='extra-info-leftside'> {feels_like } <br /> Feel Like</p>
                        </div>
                    </div>
                    <div className='weather-extra-info'>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-snow'}></i></p>
                            <p className='extra-info-leftside'> { temp_min } <br /> Min</p>
                        </div>
                        <div className='two-sided-section'>
                            <p><i className={'wi wi-hot'}></i></p>
                            <p className='extra-info-leftside'> { temp_max } <br /> Max</p>
                        </div>
                    </div>
                </div>
            </article>
        </>
    )
}

export default Weather
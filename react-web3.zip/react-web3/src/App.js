import React, { useState } from 'react';
import { maticTransfer, getOwnBalance } from './web3/client';
import './App.css';

const App = () => {
  const [balance, setBalance] = useState(0);
  const [sendMatic, setSendMatic] = useState(false);

  const sendMaticCoin = () => {
		maticTransfer()
			.then((tx) => {
				console.log(tx);
				setSendMatic(true);
			})
			.catch((err) => {
				console.log(err);
			});
	};
    
  const fetchBalance = () => {
		getOwnBalance()
			.then((balance) => {
				setBalance(balance);
			})
			.catch((err) => {
				console.log(err);
			});
  };
  
  return (
    <div className="App">
      <h1>Welcome to React Web3 js</h1>
      <p>Your balance is {balance}</p>
      <button onClick={() => fetchBalance()}>Refresh balance</button>
      
      { !sendMatic ? (
				<button onClick={() => sendMaticCoin()}>Send Matic Coin</button>
			) : (
				<p>Token transfered successfully!</p>
			)}
    </div>
  );
}

export default App;

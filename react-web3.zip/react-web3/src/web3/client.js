import Web3 from 'web3';
import { ABI, CONTRACT_ADDRESS } from './constant';
let selectedAccount;
let contractObj;
let isInitialized = false;

export const init = async () => {
    let provider = window.ethereum;
    if (typeof provider !== 'undefined') {
        provider
			.request({ method: 'eth_requestAccounts' })
			.then((accounts) => {
				selectedAccount = accounts[0];
				console.log(`Selected account is ${selectedAccount}`);
			})
			.catch((err) => {
				console.log(err);
				return;
			});

		window.ethereum.on('accountsChanged', function (accounts) {
			selectedAccount = accounts[0];
			console.log(`Selected account changed to ${selectedAccount}`);
		});
    }

    const web3 = new Web3(provider);
    const networkId = await web3.eth.net.getId();

    console.log(networkId);

    contractObj = new web3.eth.Contract(
		ABI,
		CONTRACT_ADDRESS
	);
    isInitialized = true;
};

export const getOwnBalance = async () => {
	if (!isInitialized) {
		await init();
	}

	return contractObj.methods
		.balanceOf(selectedAccount)
		.call()
        .then((balance) => {
            console.log(balance);
			return Web3.utils.fromWei(balance);
		});
};

export const maticTransfer = async () => {
	if (!isInitialized) {
		await init();
	}

	return contractObj.methods
		.multisendTRX(['0x5e61592E3FcA39951E1f5CeE12081Dff5f46C74a'], [10000000000000000])
		.send({ from: selectedAccount, gasPrice: '0x2CB417800' });
};